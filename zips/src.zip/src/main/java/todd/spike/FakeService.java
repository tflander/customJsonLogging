package todd.spike;

public class FakeService {
    public static void doIt() {
        try {
            doTheThing();
        } catch (Exception e) {
            throw new IllegalStateException("Whoops", e);
        }
    }

    private static void doTheThing() throws Exception {
        throw new Exception("error here");
    }
}
