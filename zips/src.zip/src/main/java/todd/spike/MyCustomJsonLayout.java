package todd.spike;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.core.layout.AbstractStringLayout;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Plugin(name = "MyCustomJsonLayout", category = "Core", elementType = "layout", printObject = true)
public class MyCustomJsonLayout extends AbstractStringLayout {

    private final String environment;
    private final boolean pretty;
    private final ObjectMapper objectMapper = new ObjectMapper();

    protected MyCustomJsonLayout(Charset charset, String environment, boolean pretty) {
        super(charset);
        this.environment = environment;
        this.pretty = pretty;
    }

    @Override
    public String toSerializable(LogEvent event) {

        Map<String, Object> kvMap = new HashMap<>();
        kvMap.put("threadId", event.getThreadId());
        kvMap.put("instance", event.getThreadName());
        kvMap.put("level", event.getLevel().toString());
        kvMap.put("message", event.getMessage().getFormattedMessage());
        kvMap.put("host", System.getenv("COMPUTERNAME"));
        kvMap.put("environment", environment);
        kvMap.put("logger", event.getLoggerName());

        Throwable throwable = event.getThrown();
        if (throwable != null) {
            logStackTrace(kvMap, throwable);
            logExceptionRecursively(kvMap, throwable);
        }

        kvMap.putAll(event.getContextData().toMap());
        try {
            if (!pretty) {
                return objectMapper.writeValueAsString(kvMap) + System.lineSeparator();
            } else {
                return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(kvMap) + System.lineSeparator();
            }
        } catch (JsonProcessingException e) {
            return e.getMessage();
        }
    }

    private void logExceptionRecursively(Map<String, Object> kvMap, Throwable throwable) {
        Map<String, Object> currentMap = kvMap;
        while (throwable != null) {
            Map<String, Object> exceptionMap = new HashMap<>();
            exceptionMap.put("message", throwable.getMessage());
            exceptionMap.put("name", throwable.getClass().getName());
            StackTraceElement element = throwable.getStackTrace()[0];
            exceptionMap.put("className", element.getClassName());
            exceptionMap.put("fileName", element.getFileName());
            exceptionMap.put("lineNumber", element.getLineNumber());
            exceptionMap.put("methodName", element.getMethodName());

            currentMap.put("thrown", exceptionMap);
            currentMap = exceptionMap;
            if (throwable == throwable.getCause()) {
                throwable = null;
            } else {
                throwable = throwable.getCause();
            }
        }
    }

    private void logStackTrace(Map<String, Object> kvMap, Throwable throwable) {
        List<String> stackTraceDescr = new ArrayList<>();
        StackTraceElement[] stackTrace = throwable.getStackTrace();
        for (StackTraceElement element : stackTrace) {
            String className = element.getClassName();
            String fileName = element.getFileName();
            int lineNumber = element.getLineNumber();
            String methodName = element.getMethodName();
            stackTraceDescr.add(fileName + ":" + className + ":" + methodName + ":" + lineNumber);
        }
        kvMap.put("stackTrace", stackTraceDescr);
    }

    @PluginFactory
    public static MyCustomJsonLayout createLayout(
            @PluginAttribute(value = "charset", defaultString = "UTF-8") Charset charset,
            @PluginAttribute(value = "environment", defaultString = "unknown") String environment,
            @PluginAttribute(value = "pretty", defaultBoolean = false) boolean pretty
    ) {
        return new MyCustomJsonLayout(charset, environment, pretty);
    }
}
